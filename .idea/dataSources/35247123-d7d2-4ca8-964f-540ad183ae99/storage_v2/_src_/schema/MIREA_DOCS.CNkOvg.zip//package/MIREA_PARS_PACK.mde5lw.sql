create package            mirea_pars_pack
  is 
  
  /* Параметр для логирования */
  c_repeat_val constant number(1) := 1;
    
  procedure add_direction ( in_dir_encryption in direction.dir_encryption%type,
                            in_dir_name       in direction.dir_name%type
                           );
                          
  procedure add_standart ( in_st_ext_id    in standart.st_ext_id%type,
                           in_st_dt_create in standart.st_dt_create%type,
                           in_st_order     in standart.st_order%type,
                           in_st_file_path in standart.st_file_path%type
                          );
                          
  procedure add_profile ( in_prof_name        in  profiles.prof_name%type,
                          in_prof_id_dir_encr in  profiles.prof_id_dir_encr%type,
                          out_prof_id         out profiles.prof_id%type
                         );
                         
  procedure add_department ( in_dep_name in  department.dep_name%type,
                             in_dep_code in  department.dep_code%type,
                             out_dep_id  out department.dep_id%type
                            );

  procedure add_ed_plan ( in_ed_plan_name             in  education_plan.ed_plan_name%type,
                          in_ed_plan_start_date       in  education_plan.ed_plan_start_date%type,
                          in_ed_plan_created_date     in  education_plan.ed_plan_created_date%type,
                          in_ed_plan_st_ext_id        in  education_plan.ed_plan_st_ext_id%type,
                          in_ed_plan_id_dir_encr      in  education_plan.ed_plan_id_dir_encr%type,
                          in_ed_plan_prof_id          in  education_plan.ed_plan_prof_id%type,
                          in_ed_plan_depatment        in  education_plan.ed_plan_depatment%type,
                          in_ed_plan_depatment_name   in  education_plan.ed_plan_depatment_name%type,
                          in_ed_plan_qualification_name in  qualification.qualification_name%type,
                          in_ed_plan_train_program    in  education_plan.ed_plan_train_program%type,
                          in_ed_plan_education_type   in  education_plan.ed_plan_education_type%type,
                          in_ed_plan_train_period     in  education_plan.ed_plan_train_period%type,
                          out_ed_plan_id              out education_plan.ed_plan_id%type
                         );
                         
  procedure add_competence ( in_comp_name  in  competence.comp_name%type,
                             in_comp_descr in  competence.comp_descr%type,
                             out_comp_id   out competence.comp_id%type
                            );
                            
  procedure add_discipline ( in_disc_name     in  discipline.disc_name%type,
                             in_disc_id       in  discipline.disc_id%type := null,
                             out_disc_id      out discipline.disc_id%type                              
                            );
                            
  procedure add_summary_hours ( in_disc_id      in summary_hours.disc_id%type,
                                in_SR           in summary_hours.SR%type,
                                in_control      in summary_hours.control%type,
                                in_withZET      in summary_hours.withZET%type,
                                in_hoursInZE    in summary_hours.hoursInZE%type,
                                in_hoursExpert  in summary_hours.hoursExpert%type,
                                in_hoursContact in summary_hours.hoursContact%type
                               );
                             
  procedure add_hours ( in_hours_semestr    in  hours.hours_semestr%type,
                        in_hours_lectures   in  hours.hours_lectures%type,
                        in_hours_lab        in  hours.hours_lab%type,
                        in_hours_practice   in  hours.hours_practice%type,
                        in_hours_ksr        in  hours.hours_ksr%type,
                        in_hours_srs        in  hours.hours_srs%type,
                        in_hours_control    in  hours.hours_control%type,
                        in_hours_b_ecz      in  hours.hours_b_ecz%type,
                        in_hours_b_zachet   in  hours.hours_b_zachet%type,
                        in_hours_coursework in hours.hours_coursework%type := null,
                        out_hours_id        out hours.hours_id%type
                       );
                       
  procedure add_educ_plan2competence ( in_ed_plan_id in educ_plan2competence.ed_plan_id%type,
                                       in_comp_id    in educ_plan2competence.comp_id%type
                                      );
                                     
  procedure add_discipline2comp ( in_disc_id       in discipline2comp.disc_id%type,
                                  in_comp_id       in discipline2comp.comp_id%type,
                                  in_disc_comp_key in discipline2comp.disc_comp_key%type
                                 );
                                 
  procedure add_dep2discipline ( in_disc_id       in dep2discipline.disc_id%type,
                                 in_dep_id        in dep2discipline.dep_id%type
                                );
                               
  procedure add_educ_plan2disc ( in_plan_id       in educ_plan2disc.plan_id%type,
                                 in_disc_id       in educ_plan2disc.disc_id%type
                                );
                                
  procedure add_hours2competence ( in_hours_id in hours2competence.hours_id%type,
                                   in_comp_id  in hours2competence.comp_id%type
                                  ); 
                                  
  procedure add_hours2discipline ( in_hours_id in hours2discipline.hours_id%type,
                                   in_disc_id  in hours2discipline.disc_id%type
                                  );
                                  
  procedure delete_education_plan ( in_ed_plan_name in education_plan.ed_plan_name%type);
  
end;
/

