create package body            mirea_pars_pack
  as 
  procedure add_direction ( in_dir_encryption in direction.dir_encryption%type,
                            in_dir_name       in direction.dir_name%type) 
  is
    v_is_new_dir number;
    begin
      select count(*)
        into v_is_new_dir
        from direction
       where dir_encryption = in_dir_encryption
         and dir_name = in_dir_name;
         
      if (v_is_new_dir != 0) then
        --пакет логирования в случае вставления имеющихся значений
        null;
      else
        insert into direction (dir_encryption, dir_name)
          values (in_dir_encryption, in_dir_name);
      end if;
      
    end;
                          
  procedure add_standart ( in_st_ext_id    in standart.st_ext_id%type,
                           in_st_dt_create in standart.st_dt_create%type,
                           in_st_order     in standart.st_order%type,
                           in_st_file_path in standart.st_file_path%type)
  is
    v_is_new_standart number;
    begin
      select count(*)
        into v_is_new_standart
        from standart
       where st_ext_id    = in_st_ext_id;
         
      if (v_is_new_standart != 0) then
        --пакет логирования в случае вставления имеющихся значений
       /* add_log(c_repeat_val, 'repeatable values ON Standart: ' || 
          in_st_ext_id    || ' ' || 
          in_st_dt_create || ' ' || 
          in_st_order     || ' ' || 
          in_st_file_path);*/
        null;
      else
        insert into standart (st_ext_id, st_dt_create, st_order, st_file_path)
          values (in_st_ext_id, in_st_dt_create, in_st_order, in_st_file_path);
      end if;
      
    end;
                          
  procedure add_profile ( in_prof_name        in profiles.prof_name%type,
                          in_prof_id_dir_encr in profiles.prof_id_dir_encr%type,
                          out_prof_id         out profiles.prof_id%type)
  is
     v_is_new_profile number;
    begin
      begin
      select p.PROF_ID
        into v_is_new_profile
        from profiles p
       where prof_name        = in_prof_name
         and prof_id_dir_encr = in_prof_id_dir_encr;
      exception
        when NO_DATA_FOUND then v_is_new_profile:=0;
      end;
         
      if (v_is_new_profile != 0) then
        --пакет логирования в случае вставления имеющихся значений
        /*add_log(c_repeat_val, 'repeatable values ON Profiles: ' || 
            in_prof_name || ' ' || in_prof_id_dir_encr); */
            out_prof_id := v_is_new_profile;
      else
        out_prof_id := sq_profiles.nextval;
       
        insert into profiles (prof_id, prof_name, prof_id_dir_encr)
          values (out_prof_id, in_prof_name, in_prof_id_dir_encr);
        
      end if;
      
    end;
    
    
  procedure add_department ( in_dep_name in  department.dep_name%type,
                             in_dep_code in  department.dep_code%type,
                             out_dep_id  out department.dep_id%type)
  is
  begin
    out_dep_id := sq_department.nextval;
    insert into department (dep_id, dep_name, dep_code)
      values (out_dep_id, in_dep_name, in_dep_code);
      
          
  end;
  
  function get_qualification ( in_qualification_name in  qualification.qualification_name%type)
  return number
  is
    v_is_new_qualification number := 0;
    out_qual_id number;
  begin
    begin
    select q.qualification_id
      into v_is_new_qualification
      from qualification q
     where qualification_name = in_qualification_name;
    exception
      when NO_DATA_FOUND then v_is_new_qualification:=0;
    end;
       
    if (v_is_new_qualification != 0) then
      --пакет логирования в случае вставления имеющихся значений
      /*add_log(c_repeat_val, 'repeatable values ON Profiles: ' || 
          in_prof_name || ' ' || in_prof_id_dir_encr); */
          out_qual_id := v_is_new_qualification;
    else
      out_qual_id := sq_qualification.nextval;
     
      insert into qualification (qualification_id, qualification_name)
        values (out_qual_id, in_qualification_name);
      
    end if;
    
    return out_qual_id;
  end;
  
procedure add_ed_plan ( in_ed_plan_name               in  education_plan.ed_plan_name%type,
                        in_ed_plan_start_date         in  education_plan.ed_plan_start_date%type,
                        in_ed_plan_created_date       in  education_plan.ed_plan_created_date%type,
                        in_ed_plan_st_ext_id          in  education_plan.ed_plan_st_ext_id%type,
                        in_ed_plan_id_dir_encr        in  education_plan.ed_plan_id_dir_encr%type,
                        in_ed_plan_prof_id            in  education_plan.ed_plan_prof_id%type,
                        in_ed_plan_depatment          in  education_plan.ed_plan_depatment%type,
                        in_ed_plan_depatment_name     in  education_plan.ed_plan_depatment_name%type,
                        in_ed_plan_qualification_name in  qualification.qualification_name%type,
                        in_ed_plan_train_program      in  education_plan.ed_plan_train_program%type,
                        in_ed_plan_education_type     in  education_plan.ed_plan_education_type%type,
                        in_ed_plan_train_period       in  education_plan.ed_plan_train_period%type,
                        out_ed_plan_id                out education_plan.ed_plan_id%type)
  is
  
  qualification_id number(20);
  begin
    out_ed_plan_id := sq_education_plan.nextval;
    
    qualification_id := get_qualification(in_ed_plan_qualification_name);
    
    insert into education_plan (ed_plan_id, 
                                ed_plan_name, 
                                ed_plan_start_date, 
                                ed_plan_created_date, 
                                ed_plan_st_ext_id, 
                                ed_plan_id_dir_encr, 
                                ed_plan_prof_id,
                                ed_plan_depatment,
                                ed_plan_depatment_name,
                                ed_plan_qualification_id,
                                ed_plan_train_program,
                                ed_plan_education_type,
                                ed_plan_train_period)
      values (out_ed_plan_id, 
              in_ed_plan_name, 
              in_ed_plan_start_date, 
              in_ed_plan_created_date, 
              in_ed_plan_st_ext_id, 
              in_ed_plan_id_dir_encr, 
              in_ed_plan_prof_id,
              in_ed_plan_depatment,
              in_ed_plan_depatment_name,
              qualification_id,
              in_ed_plan_train_program,
              in_ed_plan_education_type,
              in_ed_plan_train_period);
  end;  

  procedure add_competence ( in_comp_name  in  competence.comp_name%type,
                             in_comp_descr in  competence.comp_descr%type,
                             out_comp_id   out competence.comp_id%type)
  is
  begin
    out_comp_id := sq_competence.nextval;
    insert into competence (comp_id,
                            comp_name,
                            comp_descr)
      values (out_comp_id,
              in_comp_name,
              in_comp_descr);
  end;
                            
  procedure add_discipline ( in_disc_name     in  discipline.disc_name%type,
                             in_disc_id       in  discipline.disc_id%type := null,
                             out_disc_id      out discipline.disc_id%type  
                            )
  is
  begin
    if in_disc_id is null then
      out_disc_id := sq_discipline.nextval;
    end if;
    insert into discipline (disc_id,
                            disc_name)
      values (nvl(out_disc_id, in_disc_id),
              in_disc_name);
  end;
  
  procedure add_summary_hours ( in_disc_id      in summary_hours.disc_id%type,
                                in_SR           in summary_hours.SR%type,
                                in_control      in summary_hours.control%type,
                                in_withZET      in summary_hours.withZET%type,
                                in_hoursInZE    in summary_hours.hoursInZE%type,
                                in_hoursExpert  in summary_hours.hoursExpert%type,
                                in_hoursContact in summary_hours.hoursContact%type
                               )
  is
  begin
    insert into summary_hours (disc_id,
                               SR,
                               control,
                               withZET,
                               hoursInZE,
                               hoursExpert,
                               hoursContact)
      values (in_disc_id,
              in_SR,
              in_control,
              in_withZET,
              in_hoursInZE,
              in_hoursExpert,
              in_hoursContact);
  end;
                             
  procedure add_hours ( in_hours_semestr    in  hours.hours_semestr%type,
                        in_hours_lectures   in  hours.hours_lectures%type,
                        in_hours_lab        in  hours.hours_lab%type,
                        in_hours_practice   in  hours.hours_practice%type,
                        in_hours_ksr        in  hours.hours_ksr%type,
                        in_hours_srs        in  hours.hours_srs%type,
                        in_hours_control    in  hours.hours_control%type,
                        in_hours_b_ecz      in  hours.hours_b_ecz%type,
                        in_hours_b_zachet   in  hours.hours_b_zachet%type,
                        in_hours_coursework in hours.hours_coursework%type := null,
                        out_hours_id        out hours.hours_id%type)
  is
  begin
    out_hours_id := sq_hours.nextval;
    insert into hours (hours_id,
                       hours_semestr,
                       hours_lectures,
                       hours_lab,
                       hours_practice,
                       hours_ksr,
                       hours_srs,    
                       hours_control,
                       hours_b_ecz,
                       hours_b_zachet,
                       hours_coursework)
      values (out_hours_id,
              in_hours_semestr,
              in_hours_lectures,
              in_hours_lab,
              in_hours_practice,
              in_hours_ksr,
              in_hours_srs,    
              in_hours_control,
              in_hours_b_ecz,
              in_hours_b_zachet,
              in_hours_coursework);
  end;
  
  
  procedure add_educ_plan2competence ( in_ed_plan_id in educ_plan2competence.ed_plan_id%type,
                                       in_comp_id    in educ_plan2competence.comp_id%type)
  is
  begin
    insert into educ_plan2competence (ed_plan_id, comp_id)
      values (in_ed_plan_id, in_comp_id);
  end;
                                     
  procedure add_discipline2comp ( in_disc_id       in discipline2comp.disc_id%type,
                                  in_comp_id       in discipline2comp.comp_id%type,
                                  in_disc_comp_key in discipline2comp.disc_comp_key%type)
  is
  begin
    insert into discipline2comp (disc_id, comp_id, disc_comp_key)
      values (in_disc_id, in_comp_id, in_disc_comp_key);
  end;
                                 
  procedure add_dep2discipline ( in_disc_id       in dep2discipline.disc_id%type,
                                 in_dep_id        in dep2discipline.dep_id%type)
  is
  begin
    insert into dep2discipline (disc_id, dep_id)
      values (in_disc_id, in_dep_id);
  end;              
                               
  procedure add_educ_plan2disc ( in_plan_id       in educ_plan2disc.plan_id%type,
                                 in_disc_id       in educ_plan2disc.disc_id%type)
  is
  begin
    insert into educ_plan2disc (plan_id, disc_id)
      values (in_plan_id, in_disc_id);
  end;
                                
  procedure add_hours2competence ( in_hours_id in hours2competence.hours_id%type,
                                   in_comp_id  in hours2competence.comp_id%type)
  is
  begin
    insert into hours2competence (hours_id, comp_id)
      values (in_hours_id, in_comp_id);
  end;
                                  
  procedure add_hours2discipline ( in_hours_id in hours2discipline.hours_id%type,
                                   in_disc_id  in hours2discipline.disc_id%type)
  is
  begin
    insert into hours2discipline (hours_id, disc_id)
      values (in_hours_id, in_disc_id);
  end;
  
  procedure delete_education_plan ( in_ed_plan_name in education_plan.ed_plan_name%type)
  is    
  begin

    for c in (select ed_plan_id
                from education_plan
               where ed_plan_name = in_ed_plan_name) loop
      /* Удаление по стороне компетенций*/
      for c1 in (select comp_id 
                   from educ_plan2competence ep2c
                  where ep2c.ed_plan_id = c.ed_plan_id) loop
        delete from discipline2comp d2c
          where d2c.comp_id = c1.comp_id;
          
        for c12 in (select hours_id
                      from hours2competence h2c
                     where h2c.comp_id = c1.comp_id) loop
          delete from hours h
            where h.hours_id = c12.hours_id;
        end loop;
        
        delete from hours2competence h2c
          where h2c.comp_id = c1.comp_id;
          
        delete from competence comp
         where comp.comp_id = c1.comp_id;
      end loop;
      
      delete from educ_plan2competence ep2c
       where ep2c.ed_plan_id = c.ed_plan_id;
       
      /* Удаление по стороне дисциплин*/
      
      for c2 in (select disc_id
                   from educ_plan2disc ep2d
                 where ep2d.plan_id = c.ed_plan_id) loop
                 
        for c21 in (select dep_id 
                      from dep2discipline d2d
                     where d2d.disc_id = c2.disc_id) loop
          delete from department d
           where d.dep_id = c21.dep_id;
        end loop;
        
        delete from dep2discipline d2d
         where d2d.disc_id = c2.disc_id;
      
        delete from hours2discipline h2d
         where h2d.disc_id = c2.disc_id;
         
         
        delete from SUMMARY_HOURS sh
        where sh.disc_id = c2.disc_id;
         
        delete from discipline d
         where d.disc_id = c2.disc_id;
      end loop;
      
      delete from educ_plan2disc ep2d
       where ep2d.plan_id = c.ed_plan_id;
       
      delete from education_plan e
       where e.ed_plan_id = c.ed_plan_id;
       
    end loop;

  end;
            
end;
/

