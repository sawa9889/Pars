create procedure            add_log ( in_log_text varchar2,
                                                 in_log_type log_tab.log_type_id%type)
  is
  pragma autonomous_transaction;
  begin
    insert into log_tab (log_text, log_type_id)
      values (in_log_text, in_log_type);
    commit;
  end;
/

