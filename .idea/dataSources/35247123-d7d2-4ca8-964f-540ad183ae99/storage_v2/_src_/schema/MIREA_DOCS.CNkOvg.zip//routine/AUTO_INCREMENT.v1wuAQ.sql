create procedure            auto_increment(
                                            owner_name in varchar2,
                                            tab_name   in varchar2) 
is 
  check_tab number(10);
  pk_name varchar2(1024);
begin

  select count(*)
    into check_tab
    from all_tables
   where lower(owner) = lower(owner_name)
   and lower(table_name) = lower(tab_name);
   
   if (check_tab != 1) then
     raise no_data_found;
   end if;

  select cols.column_name
    into pk_name
    from all_constraints cons, all_cons_columns cols
   where lower(cols.table_name) = lower(tab_name)
   and lower(cols.owner) = lower(owner_name)
   and cons.constraint_type = 'P'
   and cons.constraint_name = cols.constraint_name
   and cons.owner = cols.owner
  order by cols.table_name, cols.position;
  
  execute immediate 'create sequence sq_' || lower(tab_name) || ' nocache';
  
  execute immediate 'create or replace trigger ' || lower(tab_name) || '_tg 
                       before insert on ' || lower(tab_name) || '
                       for each row
                       when (new.'|| pk_name ||' is null)
                         begin
                           select sq_' || lower(tab_name) || '.nextval into :NEW."' || pk_name || '" from dual; 
                         end;';
end;
/

