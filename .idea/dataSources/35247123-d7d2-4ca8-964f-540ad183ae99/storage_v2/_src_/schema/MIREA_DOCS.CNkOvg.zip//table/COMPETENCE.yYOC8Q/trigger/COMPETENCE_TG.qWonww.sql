create trigger COMPETENCE_TG
  before insert
  on COMPETENCE
  for each row
  when (new.COMP_ID is null)
begin
                           select sq_competence.nextval into :NEW."COMP_ID" from dual; 
                         end;
/

