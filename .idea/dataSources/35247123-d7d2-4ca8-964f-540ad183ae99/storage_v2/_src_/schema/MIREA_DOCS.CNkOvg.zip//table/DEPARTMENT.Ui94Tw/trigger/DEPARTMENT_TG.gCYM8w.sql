create trigger DEPARTMENT_TG
  before insert
  on DEPARTMENT
  for each row
  when (new.DEP_ID is null)
begin
                           select sq_department.nextval into :NEW."DEP_ID" from dual; 
                         end;
/

