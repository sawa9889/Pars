create trigger DISCIPLINE_TG
  before insert
  on DISCIPLINE
  for each row
  when (new.DISC_ID is null)
begin
                           select sq_discipline.nextval into :NEW."DISC_ID" from dual; 
                         end;
/

