create trigger DOCUMENT_TG
    before insert
    on DOCUMENT
    for each row
    when (new.DOC_ID is null)
begin
                           select sq_document.nextval into :NEW."DOC_ID" from dual; 
                         end;
/

