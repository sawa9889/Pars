create trigger DOCUMENT_TYPE_TG
    before insert
    on DOCUMENT_TYPE
    for each row
    when (new.DOC_TYPE_ID is null)
begin
                           select sq_document_type.nextval into :NEW."DOC_TYPE_ID" from dual; 
                         end;
/

