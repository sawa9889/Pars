create trigger EDUCATION_CERTIFICATE_TG
    before insert
    on EDUCATION_CERTIFICATE
    for each row
    when (new.ED_CTF_ID is null)
begin
                           select sq_education_certificate.nextval into :NEW."ED_CTF_ID" from dual; 
                         end;
/

