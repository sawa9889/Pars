create trigger EDUCATION_PLAN_TG
  before insert
  on EDUCATION_PLAN
  for each row
  when (new.ED_PLAN_ID is null)
begin
                           select sq_education_plan.nextval into :NEW."ED_PLAN_ID" from dual; 
                         end;
/

