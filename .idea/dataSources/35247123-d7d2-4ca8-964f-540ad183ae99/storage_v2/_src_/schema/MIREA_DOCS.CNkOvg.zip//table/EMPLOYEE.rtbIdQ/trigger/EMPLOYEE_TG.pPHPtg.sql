create trigger EMPLOYEE_TG
    before insert
    on EMPLOYEE
    for each row
    when (new.EMPLOYEE_ID is null)
begin
                           select sq_employee.nextval into :NEW."EMPLOYEE_ID" from dual; 
                         end;
/

