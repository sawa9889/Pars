create trigger HOURS_TG
  before insert
  on HOURS
  for each row
  when (new.HOURS_ID is null)
begin
                           select sq_hours.nextval into :NEW."HOURS_ID" from dual; 
                         end;
/

