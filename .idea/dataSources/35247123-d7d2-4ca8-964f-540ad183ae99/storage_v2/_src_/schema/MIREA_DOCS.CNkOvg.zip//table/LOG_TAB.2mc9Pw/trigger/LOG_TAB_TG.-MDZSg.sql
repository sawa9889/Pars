create trigger LOG_TAB_TG
  before insert
  on LOG_TAB
  for each row
  when (new.LOG_TAB_ID is null)
begin
                           select sq_log_tab.nextval into :NEW."LOG_TAB_ID" from dual; 
                         end;
/

