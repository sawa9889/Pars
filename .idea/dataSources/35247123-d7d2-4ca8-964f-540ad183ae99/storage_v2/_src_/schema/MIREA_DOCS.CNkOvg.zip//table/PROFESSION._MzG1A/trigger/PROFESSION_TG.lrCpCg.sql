create trigger PROFESSION_TG
    before insert
    on PROFESSION
    for each row
    when (new.PROF_ID is null)
begin
                           select sq_profession.nextval into :NEW."PROF_ID" from dual; 
                         end;
/

