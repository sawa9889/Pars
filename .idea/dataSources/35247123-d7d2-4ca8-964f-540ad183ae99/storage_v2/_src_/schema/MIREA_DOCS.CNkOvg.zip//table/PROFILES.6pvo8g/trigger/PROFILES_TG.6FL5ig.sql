create trigger PROFILES_TG
  before insert
  on PROFILES
  for each row
  when (new.PROF_ID is null)
begin
                           select sq_profiles.nextval into :NEW."PROF_ID" from dual; 
                         end;
/

