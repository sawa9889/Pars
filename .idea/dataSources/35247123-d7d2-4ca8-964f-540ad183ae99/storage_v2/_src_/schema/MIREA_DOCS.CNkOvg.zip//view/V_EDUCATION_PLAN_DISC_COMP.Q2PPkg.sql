create view V_EDUCATION_PLAN_DISC_COMP as
SELECT     ed.ed_plan_id,
           ed.ed_plan_name,
           disc.disc_id,          
           disc.disc_name,
           comp.comp_id,
           comp.comp_name,
           comp.comp_descr
      FROM education_plan        ed,
           educ_plan2competence  ed2comp,
           educ_plan2disc        ed2disc,
           competence            comp,
           discipline            disc,
           discipline2comp       disc2comp
     WHERE     ed2comp.ed_plan_id = ed.ed_plan_id
           AND ed2disc.plan_id = ed.ed_plan_id
           AND ed2comp.comp_id = comp.comp_id
           AND disc.disc_id = ed2disc.disc_id
           AND disc.disc_id = disc2comp.disc_id
           AND comp.comp_id = disc2comp.comp_id
WITH CHECK OPTION
/

