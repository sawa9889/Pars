create view V_EDUCATION_PLAN_MAIN_INFO as
    WITH
        stub_data
        AS
            (SELECT'Test teacher' teacher,
                    1             coursework
               FROM DUAL)
    SELECT ed.ed_plan_id,
           ed.ed_plan_name,
           ed.ed_plan_start_date,
           prof.prof_name,
           dir.dir_name,
           dir.dir_encryption,
           ed.ED_PLAN_DEPATMENT,
           q.QUALIFICATION_NAME,
           ed.ED_PLAN_EDUCATION_TYPE,
           ed.ED_PLAN_TRAIN_PERIOD,
           comp.comp_id,
           dep.dep_name,
           dep.dep_code,
           disc2comp.disc_comp_key,
           disc.disc_id,
           disc.disc_name,
           stub_data.teacher,
           h.hours_b_ecz            AS is_exam,
           h.hours_b_zachet         AS is_offset,
           h.hours_control,
           h.hours_ksr,
           h.hours_lab,
           h.hours_lectures,
           h.hours_practice,
           h.hours_semestr,
           h.hours_srs,
           sh.control               AS sh_control,
           sh.hourscontact          AS sh_contact,
           sh.hoursexpert           AS sh_expert,
           sh.sr                    AS sh_sr,
           sh.withzet               AS sh_with_zet,
           stub_data.coursework     AS course_work
      FROM education_plan        ed,
           profiles              prof,
           direction             dir,
           educ_plan2competence  ed2comp,
           educ_plan2disc        ed2disc,
           competence            comp,
           discipline            disc,
           dep2discipline        dep2disc,
           department            dep,
           discipline2comp       disc2comp,
           hours2discipline      h2disc,
           hours                 h,
           summary_hours         sh,
           qualification         q,
           stub_data
     WHERE     ed.ed_plan_prof_id = prof.prof_id
           AND dir.dir_encryption = ed.ed_plan_id_dir_encr
           AND ed2comp.ed_plan_id = ed.ed_plan_id
           AND q.QUALIFICATION_ID = ed.ED_PLAN_QUALIFICATION_ID
           AND ed2disc.plan_id = ed.ed_plan_id
           AND ed2comp.comp_id = comp.comp_id
           AND disc.disc_id = ed2disc.disc_id
           AND dep2disc.disc_id = disc.disc_id
           AND dep.dep_id = dep2disc.dep_id
           AND disc.disc_id = disc2comp.disc_id
           AND comp.comp_id = disc2comp.comp_id
           AND h2disc.disc_id = disc.disc_id
           AND h.hours_id = h2disc.hours_id
           AND sh.disc_id = disc.disc_id
WITH CHECK OPTION
/

